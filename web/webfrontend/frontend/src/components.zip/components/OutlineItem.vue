<template>
  <div class="outline-item">
    <el-row align="middle" justify="space-between">
      <el-col :span="20">
      <div class="outline-title" :style="getItemStyle(item)">
        {{ item.title }}
      </div>
      </el-col>
      <el-col :span="4" class="outline-actions">
<el-button class="icon-btn" size="small" @click="$emit('edit', item)">
  <el-icon><Edit /></el-icon>
</el-button>
<el-button class="icon-btn" size="small" @click="$emit('add-child', item)">
  <el-icon><Plus /></el-icon>
</el-button>
<el-button class="icon-btn" size="small" type="danger" @click="$emit('remove')">
  <el-icon><Delete /></el-icon>
</el-button>
      </el-col>
    </el-row>
    <div class="outline-children">
      <OutlineItem
        v-for="(child, index) in item.children"
        :key="child.id"
        :item="child"
        @edit="$emit('edit', $event)"
        @add-child="$emit('add-child', $event)"
        @remove="() => Array.isArray(item.children) && item.children.splice(index, 1)"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { defineProps, defineEmits } from 'vue'
import type { OutlineItemType } from './types'
import { Edit, Plus, Delete } from '@element-plus/icons-vue'

const props = defineProps<{ item: OutlineItemType }>()
const emit = defineEmits(['edit', 'add-child', 'remove'])

const sizeMap: Record<string, string> = {
  '初号': '42px',
  '小初': '36px',
  '一号': '26px',
  '小一': '24px',
  '二号': '22px',
  '小二': '18px',
  '三号': '16px',
  '四号': '14px',
  '五号': '12px',
  '小五': '10.5px',
  '六号': '9px',
  '七号': '7.5px',
}

const getItemStyle = (item: OutlineItemType) => {
  return {
    fontFamily: item.font,
    fontSize: sizeMap[item.size] || '14px',
    color: item.color,
    fontWeight: item.bold ? 'bold' : 'normal',
    fontStyle: item.italic ? 'italic' : 'normal',
  }
}

</script>

<style scoped>
.outline-item {
  padding: 10px;
  margin-bottom: 10px;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  background: #fff;
}
.outline-actions {
  display: flex;
  justify-content: flex-end;
  gap: 6px;
}
.outline-children {
  padding-left: 20px;
  margin-top: 8px;
}
.outline-title {
  font-weight: 500;
  line-height: 1.6;
}
.icon-btn {
  width: 32px;
  height: 32px;
  padding: 0;
  border-radius: 4px; /* 让它不要是圆的 */
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
