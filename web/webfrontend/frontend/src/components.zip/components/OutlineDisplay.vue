<template>
  <div v-for="section in sections" :key="section.id" class="section-block">
    <el-card shadow="never">
      <!-- 段落标题 -->
      <template #header>
        <div class="section-header">
          <h3>{{ section.title }}</h3>
          <el-button type="info" size="small">编辑</el-button>
        </div>
      </template>

      <!-- 知识注入标识（占位） -->
      <p class="kb-flag">📚 知识注入：无注入内容</p>

      <!-- 正文内容区 -->
      <div class="section-content">
        <div v-if="section.content" class="text-content">
          {{ section.content }}
        </div>
        <div v-else class="text-placeholder">无正文内容</div>
      </div>

      <!-- 生成正文按钮 -->
      <el-button
        type="primary"
        size="small"
        class="generate-btn"
        @click="$emit('generate', {
          id: section.id,
          title: section.title,
          outline: section.outline,
          content: section.content
        })"
      >
        生成正文
      </el-button>
    </el-card>
  </div>
</template>

<script setup lang="ts">
export interface OutlineSection {
  id: string
  title: string
  outline: string
  content: string
}

defineProps<{
  sections: OutlineSection[]
}>()
</script>

<style scoped>
.section-block {
  margin-bottom: 20px;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.kb-flag {
  font-size: 13px;
  color: #999;
  margin-bottom: 10px;
}

.text-content {
  font-size: 14px;
  line-height: 1.6;
  white-space: pre-wrap;
  color: #333;
  margin-bottom: 10px;
}

.text-placeholder {
  font-size: 13px;
  font-style: italic;
  color: #ccc;
  margin-bottom: 10px;
}

.generate-btn {
  margin-top: 10px;
}
</style>
